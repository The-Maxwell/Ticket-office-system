create
    definer = root@localhost procedure getTicketInfoValues(IN dateStart date, IN dateEnd date, OUT countTickets bigint,
                                                           OUT money decimal(10, 2), OUT strResult varchar(80))
BEGIN
  DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN 
    GET DIAGNOSTICS CONDITION 1 strResult = MESSAGE_TEXT;
  END;

  IF dateStart >= dateEnd THEN SIGNAL SQLSTATE '45000' set MESSAGE_TEXT='Error: End date must be greater than the start date!';
  END IF;
  SET countTickets = (SELECT COUNT(*) FROM ticket t, receipt r WHERE (t.Reciept_id=r.Receipt_code) AND (r.Data_and_time_of_sale BETWEEN dateStart AND dateEnd));
  SET money = (SELECT SUM(t.Cost) FROM ticket t, receipt r WHERE (t.Reciept_id=r.Receipt_code) AND (r.Data_and_time_of_sale BETWEEN dateStart AND dateEnd));
  SET strResult = 'The SELECT was successful';
END;

