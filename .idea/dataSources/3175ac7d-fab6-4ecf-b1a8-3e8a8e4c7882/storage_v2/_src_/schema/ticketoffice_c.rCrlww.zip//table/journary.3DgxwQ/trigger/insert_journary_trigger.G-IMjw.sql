create definer = root@localhost trigger Insert_journary_trigger
    after insert
    on journary
    for each row
BEGIN
  IF NEW.Departure_point=NEW.Destination THEN
    SIGNAL SQLSTATE '45000' set MESSAGE_TEXT='Error: The destination of the flight must be different from the place of departure!';
  ELSEIF NEW.Date_and_time_of_arrival>=NEW.Date_and_time_of_departure THEN
    SIGNAL SQLSTATE '45000' set MESSAGE_TEXT='Error: The flight start time must be less than the end time!';
  END IF;
END;

