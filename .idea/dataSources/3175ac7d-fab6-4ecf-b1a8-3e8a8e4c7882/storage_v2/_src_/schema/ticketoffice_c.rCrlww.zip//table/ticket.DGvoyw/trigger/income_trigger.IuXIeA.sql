create definer = root@localhost trigger Income_trigger
    before insert
    on ticket
    for each row
    UPDATE journary j
  SET j.Income = j.Income + NEW.Cost
  WHERE j.Journary_number = NEW.Journary_id;

