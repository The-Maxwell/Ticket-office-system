create
    definer = root@localhost procedure addPassenger(IN last_name varchar(40), IN first_name varchar(40),
                                                    IN surname varchar(40), IN category varchar(40),
                                                    OUT strResult varchar(80))
BEGIN
  DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN 
    GET DIAGNOSTICS CONDITION 1 strResult = MESSAGE_TEXT;
  END;

  IF category NOT IN ('Дитина до 4 років', 'Школяр', 'Студент', 'Без пільг', 'Пенсіонер', 'Людина з інвалідністю') 
  THEN SIGNAL SQLSTATE '45000' set MESSAGE_TEXT='Error: Invalid category!';
  END IF;

  INSERT passenger(Last_name,First_name,Surname,Category) 
  VALUES (last_name,first_name, surname,category);
  SET strResult = 'The INSERT was successful';

END;

