create view report2 as
select `v`.`Vehicle_code`                  AS `Vehicle_code`,
       `v`.`Vehicle_type`                  AS `Vehicle_type`,
       `v`.`Number_of_seats`               AS `Number_of_seats`,
       `v`.`Number_of_economy_class_seats` AS `Number_of_economy_class_seats`,
       `v`.`Number_of_medium_class_seats`  AS `Number_of_medium_class_seats`,
       `v`.`Number_of_luxury_class_seats`  AS `Number_of_luxury_class_seats`,
       `v`.`Vechile_company`               AS `Vechile_company`,
       `j`.`Journary_number`               AS `Journary_number`,
       `j`.`Departure_point`               AS `Departure_point`,
       `j`.`Destination`                   AS `Destination`,
       `j`.`Date_and_time_of_arrival`      AS `Date_and_time_of_arrival`,
       `j`.`Date_and_time_of_departure`    AS `Date_and_time_of_departure`,
       `j`.`Vechile_id`                    AS `Vechile_id`,
       `j`.`Income`                        AS `Income`,
       `t`.`Ticket_number`                 AS `Ticket_number`,
       `t`.`Category`                      AS `Category`,
       `t`.`Cost`                          AS `Cost`,
       `t`.`Sequence_number`               AS `Sequence_number`,
       `t`.`Reciept_id`                    AS `Reciept_id`,
       `t`.`Journary_id`                   AS `Journary_id`
from `ticketoffice_c`.`vehicle` `v`
         join `ticketoffice_c`.`journary` `j`
         join `ticketoffice_c`.`ticket` `t`
where ((`v`.`Vehicle_code` = `j`.`Vechile_id`) and (`j`.`Journary_number` = `t`.`Journary_id`))
order by `v`.`Vehicle_code`, `j`.`Journary_number`;

