create view report3 as
select `ticketoffice_c`.`passenger`.`Category` AS `Category`, count(0) AS `categoryCount`
from `ticketoffice_c`.`passenger`
group by `ticketoffice_c`.`passenger`.`Category`;

