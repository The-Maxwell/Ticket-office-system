create
    definer = root@localhost procedure ticketReport(IN dateStart date, IN dateEnd date)
BEGIN
  DECLARE strErr varchar(80);
  DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN 
    GET DIAGNOSTICS CONDITION 1 strErr = MESSAGE_TEXT;
    SELECT strErr AS 'Error';
  END;

  IF dateStart >= dateEnd THEN SIGNAL SQLSTATE '45000' set MESSAGE_TEXT='Error: End date must be greater than the start date!';
  END IF;

  SELECT CAST(rec.Data_and_time_of_sale AS date) AS 'Дата', j.Journary_number AS 'Номер рейсу',
  v.Number_of_seats AS 'Загальна кількість місць', COUNT(t. Ticket_number) AS 'Кількість проданих квитків'
  FROM journary AS j, vehicle AS v, ticket AS t, receipt AS rec
  WHERE (v.Vehicle_code=j.Vechile_id) AND (SELECT COUNT(t.Ticket_number)
    FROM receipt AS r
    WHERE (r.Receipt_code=rec.Receipt_code) AND (t.Journary_id=j.Journary_number) AND (r.Receipt_code=t.Reciept_id)
    AND (r.Data_and_time_of_sale BETWEEN dateStart AND dateEnd))
  GROUP BY CAST(rec.Data_and_time_of_sale AS date), j.Journary_number;

END;

